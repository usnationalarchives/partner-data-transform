import csv

print('Generating CSV files...')
with open('m546-objects.csv', 'r', newline='') as log :
	readfile = csv.reader(log, delimiter= ',')
	for row in readfile:
		with open(row[2] + '.csv', 'a', newline='') as write:
			writelog = csv.writer(write, delimiter= ',', quoting=csv.QUOTE_ALL)
			try:
				writelog.writerow( (row[0], row[1], row[2], row[3]) )
			except IndexError:
				pass
print('Complete.')